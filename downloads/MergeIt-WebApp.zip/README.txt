Merge It - Offline Browser App

1. Extract this ZIP file.
2. Open app/index.html in a modern web browser.
3. Choose a spreadsheet and a .pptx template, then create your presentations.

Your files are processed locally in your browser and are not uploaded.
Ads are disabled in this offline file:// copy; ads only load on the hosted website when valid AdSense IDs are configured.
For the Windows desktop app and help, visit https://tsguideman.github.io/Merge-It-Site/